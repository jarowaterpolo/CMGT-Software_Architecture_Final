using JJN.PlayerSystem.Movement;
using System.Collections;
using UnityEngine;

namespace JJN.PlayerSystem.Inventory
{
    public class PlayerEquipmentController : MonoBehaviour
    {
        [SerializeField]
        private PlayerInventoryController inventoryController;
        [SerializeField]
        private Inventory playerInventory;
        [SerializeField]
        private EquipmentPresenter equipmentPresenter;

        private Weapon weaponData = null;
        private Shield shieldData = null;
        private SpecialItem itemData = null;

        private bool isCurrentlyBlocking = false;

        private void Start()
        {
            StartCoroutine(GetStartingEquipment());
        }

        private void Update()
        {
            if (!inventoryController.inInventory)
            {
                if (Input.GetMouseButtonDown(0))
                {
                    if (weaponData != null)
                    {
                        EventBus<AttackEventData>.Publish(new AttackEventData(weaponData, gameObject));
                        Debug.Log($"{weaponData.ItemName} used to attack");
                    }
                }


                if (shieldData != null)
                {
                    if (Input.GetMouseButtonDown(1) && !isCurrentlyBlocking)
                    {
                        EventBus<DefendEventData>.Publish(new DefendEventData(shieldData, gameObject, true));
                        Debug.Log($"using {shieldData.ItemName} to defend");
                        isCurrentlyBlocking = true;
                    }

                    if (Input.GetMouseButtonUp(1) && isCurrentlyBlocking)
                    {
                        EventBus<DefendEventData>.Publish(new DefendEventData(shieldData, gameObject, false));
                        Debug.Log($"stopped defending");
                        isCurrentlyBlocking = false;
                    }
                }

                if (Input.GetKeyDown(KeyCode.Q))
                {
                    if (itemData != null)
                    {
                        EventBus<ItemUseEventData>.Publish(new ItemUseEventData(itemData, gameObject));
                        Debug.Log($"{itemData.ItemName} used");
                        itemData = SearchForSameItem(itemData);
                    }
                }

                if (Input.GetKeyDown(KeyCode.E))
                {
                    EventBus<OpenItemContainerEventData>.Publish(new OpenItemContainerEventData(transform));
                    Debug.Log("open item container event published");
                }
            }
        }

        public IEnumerator GetStartingEquipment()
        {
            yield return null;
            foreach (Item item in playerInventory.Items)
            {
                if (item == null) continue;

                //Debug.Log($"{item.ItemName} is a {item.ItemType}");

                switch (item)
                {
                    case Weapon weapon:
                        weaponData = weapon;
                        equipmentPresenter.PresentItem(item, 1);
                        //Debug.Log($"{item.ItemName} copied to weaponData");
                        break;

                    case Shield shield:
                        shieldData = shield;
                        equipmentPresenter.PresentItem(item, 1);
                        //Debug.Log($"{item.ItemName} copied to shieldData");
                        break;

                    case SpecialItem specialItem:
                        itemData = specialItem;
                        //Debug.Log($"{item.ItemName} copied to itemData");
                        break;
                }
            }
        }

        public SpecialItem SearchForSameItem(SpecialItem itemToSearchFor)
        {
            foreach (SpecialItem item in playerInventory.Items)
            {
                if (item == null) continue;

                if (item.Id == itemToSearchFor.Id)
                {
                    Debug.Log($"{item.ItemName} was found to replace{itemToSearchFor.ItemName}");
                    return item;
                }
            }
            return null;
        }

        void EquipItem(EventData eventData)
        {
            EquipItemEventData equipItemEventData = (EquipItemEventData)eventData;

            switch (equipItemEventData.itemToEquip)
            {
                case Weapon weapon:
                    weaponData = weapon;
                    equipmentPresenter.PresentItem(weapon, 1);
                    break;
                case Shield shield:
                    equipmentPresenter.PresentItem(shield, 1);
                    shieldData = shield;
                    break;
                case SpecialItem specialItem:
                    itemData = specialItem;
                    break;
            }

            Debug.Log($"{equipItemEventData.itemToEquip} was just equiped");
        }

        private void OnEnable()
        {
            EventBus<EquipItemEventData>.OnEventPublished += EquipItem;
        }

        private void OnDisable()
        {
            EventBus<EquipItemEventData>.OnEventPublished -= EquipItem;
        }
    }
}